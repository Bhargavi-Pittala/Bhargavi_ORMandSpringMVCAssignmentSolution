use crm1;




INSERT INTO `customer` VALUES 
	(1,'David@gl.com','David','Adams'),
	(2,'Maxwell@gl.com','Maxwell','Dixon'),
	(3,'John@gl.com','Doe','John'),
	(4,'Mary@gl.com','Public','Mary'),
	(5,'Ajay@gl.com','Ajay','Rao');


